<?php
    
    $str="123456789";
    //echo md5();
    echo "<br/>";
    echo base64_encode($str);
    //$enc=base64_encode($str);
    //echo base64_decode($enc);
?>